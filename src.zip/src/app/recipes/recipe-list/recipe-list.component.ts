import { Component, OnInit,EventEmitter, Output } from '@angular/core';
import {Recipe} from '../recipe.model'; 

@Component({
  selector: 'app-recipe-list',
  templateUrl: './recipe-list.component.html',
  styleUrls: ['./recipe-list.component.css']
})
export class RecipeListComponent implements OnInit {
  @Output()  recipeWasSelected=new EventEmitter<Recipe>();
  recipes:Recipe[] = [
    new Recipe('A test recipe','this is a test','https://get.pxhere.com/photo/dish-meal-food-vegetable-recipe-cuisine-vegetarian-food-parmigiana-1417897.jpg'),
    new Recipe('A test recipe','this is a test','https://cdn.pixabay.com/photo/2016/06/15/19/09/food-1459693_960_720.jpg'),
    new Recipe('A test recipe','this is a test','https://c1.peakpx.com/wallpaper/400/456/943/dishes-kitchen-bio-food-recipe-wallpaper-preview.jpg')
  ];
  constructor() { }

  ngOnInit(){
  }
  onRecipeSelected(recipe:Recipe){
    this.recipeWasSelected.emit(recipe);
  }

}
